//
//  CZModel.h
//  题1
//
//  Created by iOS001 on 15/12/12.
//  Copyright © 2015年 iOS001. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YCMainCellModel : NSObject

//点击的状态
@property (nonatomic,assign) BOOL isClick;

@end
