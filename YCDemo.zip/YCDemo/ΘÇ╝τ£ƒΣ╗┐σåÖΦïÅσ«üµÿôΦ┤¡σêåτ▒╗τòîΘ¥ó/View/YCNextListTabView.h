//
//  YCNextListTabView.h
//  逼真仿写苏宁易购分类界面
//
//  Created by 刘胤辰 on 16/8/6.
//  Copyright © 2016年 it.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YCNextListTabView : UITableView



@end
